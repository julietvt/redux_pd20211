import logo from './logo.svg';
import './App.css';
import Counter from './components/Counter';
import React, { Component } from 'react';

function App() {
  return (
    <>
      <Counter />
    </>
  );
}

export default App;
